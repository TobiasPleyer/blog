import logging

LOG_LEVEL = 40

logging.basicConfig(level=LOG_LEVEL)

LOG_HANDLER = logging.NullHandler()

PER_MODULE_LOG_LEVELS = {
    'moduleA': 40,
    'moduleB': 40,
}
