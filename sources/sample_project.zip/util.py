import logging
import logging.handlers
import log_config

def setup_logger(name):
    logger = logging.getLogger(name)
    logger.propagate = False
    log_level = log_config.LOG_LEVEL

    if name in log_config.PER_MODULE_LOG_LEVELS:
        log_level = log_config.PER_MODULE_LOG_LEVELS[name]
        logger.setLevel(log_level)

    fh = logging.handlers.MemoryHandler(2048, target=log_config.LOG_HANDLER)
    fh.setLevel(log_level)
    logger.addHandler(fh)
    return (logger, log_level)